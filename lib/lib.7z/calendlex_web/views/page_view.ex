defmodule CalendlexWeb.PageView do
  use CalendlexWeb, :view
end
