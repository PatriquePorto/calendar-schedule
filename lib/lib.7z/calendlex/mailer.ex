defmodule Calendlex.Mailer do
  use Swoosh.Mailer, otp_app: :calendlex
end
